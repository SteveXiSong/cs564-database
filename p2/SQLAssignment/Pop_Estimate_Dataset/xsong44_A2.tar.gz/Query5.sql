SELECT 
	NAME, NETMIG2011
FROM 
	POP_ESTIMATE_METRO_MICRO
WHERE 
	LSAD = 'Metropolitan Statistical Area'
;
--select NAME and NETMIG where LSAD == 'MSA'
