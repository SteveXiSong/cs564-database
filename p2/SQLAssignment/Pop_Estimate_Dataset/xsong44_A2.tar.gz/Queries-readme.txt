Q1:
	Works as expected.
	What i did it try to select the state code column and house estimate
in 2011 from the table HOUSING_UNITS_STATE_LEVEL	
----------------------------------------------------------------------------
Q2
	Works as expected.
	First, in the FROM section, I select state code, sum of the births in
2012 grouped by STATE code. Then, among the selected table, I select STATE,
and sum which is greated than 80000 as the final results.		

	I have excluded (county no. == 0).
----------------------------------------------------------------------------
Q3:
	Works as expected.
----------------------------------------------------------------------------
Q4:
	Works as expected.
	I have excluded (county no. == 0)
----------------------------------------------------------------------------
Q5:
	Works as expected.
----------------------------------------------------------------------------
Q6:
	Works as expected.
----------------------------------------------------------------------------
Q7:
	Works as expected.
----------------------------------------------------------------------------
Q8:
	Works as expected.
----------------------------------------------------------------------------
Q9:
	Works as expected.
----------------------------------------------------------------------------
Q10:
	Works as expected.
----------------------------------------------------------------------------
Q11:
	Works as expected.
----------------------------------------------------------------------------
Q12: 
	Works as expected.
----------------------------------------------------------------------------
