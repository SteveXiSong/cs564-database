SELECT H.STATE, H.HUEST_2011
FROM HOUSING_UNITS_STATE_LEVEL H;
--select state code and housing estimate from the table
